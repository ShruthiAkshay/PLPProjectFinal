function toggle(id){
	switch(id){
		case 'id01':
			document.getElementById('id01').style.display='block';
			document.getElementById('id03').style.display='none';
			document.getElementById('id04').style.display='none';
			document.getElementById('id05').style.display='none';
			document.getElementById('id06').style.display='none';
			break;
		case 'id02':
			document.getElementById('id01').style.display='none';
			document.getElementById('id02').style.display='block';
			document.getElementById('id03').style.display='none';
			document.getElementById('id04').style.display='none';
			document.getElementById('id05').style.display='none';
			document.getElementById('id06').style.display='none';
			break;
		case 'id03':
			document.getElementById('id03').style.display='block';
			document.getElementById('id01').style.display='none';
			document.getElementById('id04').style.display='none';
			document.getElementById('id05').style.display='none';
			document.getElementById('id06').style.display='none';
			break;
		case 'id03_1':
			document.getElementById('id03').style.display='block';
			document.getElementById('id01').style.display='none';
			document.getElementById('id04').style.display='none';
			document.getElementById('id05').style.display='none';
			document.getElementById('id06').style.display='none';
			break;
		case 'id04':
			document.getElementById('id04').style.display='block';
			document.getElementById('id01').style.display='none';
			document.getElementById('id03').style.display='none';
			document.getElementById('id05').style.display='none';
			document.getElementById('id06').style.display='none';
			break;
		case 'id04_1':
			document.getElementById('id04').style.display='block';
			document.getElementById('id01').style.display='none';
			document.getElementById('id03').style.display='none';
			document.getElementById('id05').style.display='none';
			document.getElementById('id06').style.display='none';
			break;	
		case 'id05':
			document.getElementById('id05').style.display='block';
			document.getElementById('id01').style.display='none';
			document.getElementById('id03').style.display='none';
			document.getElementById('id04').style.display='none';
			document.getElementById('id06').style.display='none';
			break;
		case'id06':
			document.getElementById('id01').style.display='none';
			document.getElementById('id03').style.display='none';
			document.getElementById('id04').style.display='none';
			document.getElementById('id05').style.display='none';
			document.getElementById('id06').style.display='block';
			break;
	}
	return;
}

