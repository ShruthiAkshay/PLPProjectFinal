package com.capgemini.fms.service;

import com.capgemini.fms.dto.FeedBackBean;
import com.capgemini.fms.exception.FeedBackException;


public interface IParticipantService {

	public boolean participantFeedback(FeedBackBean feedBack) throws  FeedBackException;
	public String retrieveTrCode(String employeeCode);
}
