package com.capgemini.fms.service;

import com.capgemini.fms.dto.EmployeeBean;

public interface IEmployeeService {

	public EmployeeBean employeeLogin(String employeeCode, String password);

	public String retreiveTrainingCode(String employeeCode);
}
