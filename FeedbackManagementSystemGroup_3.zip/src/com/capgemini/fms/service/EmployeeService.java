package com.capgemini.fms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.fms.dao.EmployeeDAO;
import com.capgemini.fms.dao.IEmployeeDAO;
import com.capgemini.fms.dto.EmployeeBean;
import com.capgemini.fms.exception.FeedBackException;

@Service
public class EmployeeService implements IEmployeeService{

	String role="wrong";
	@Autowired
	IEmployeeDAO employeeDao;
	//------------------------ Feedback Management System --------------------------//
	/*******************************************************************************
	 - Function Name	:	employeeLogin()
	 - Input Parameters	:   employeeCode,password
	 - Return Type		:	String
	 - Throws			:  	FeedBackException 
	 - Author			:	GROUP-5
	 - Description		:   employeeLogin method calls dao method and returns role
	 						of the employee after verifying from employeeMaster table
	 ********************************************************************************/
	
	@Override
	public EmployeeBean employeeLogin(String employeeCode, String password) {
		if((isValidEmployeeCode(employeeCode))&&(isValidPassword(password))){
			return employeeDao.employeeLogin(employeeCode, password);
		}
		else
			return null;
	}
	
	@Override
	public String retreiveTrainingCode(String employeeCode) {
		
		return employeeDao.retreiveTrainingCode(employeeCode);
	}


	public void validateEmployee(EmployeeBean bean) throws FeedBackException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating Employee Code
		if(!(isValidEmployeeCode(bean.getEmployeeCode()))) {
			validationErrors.add("\n Please enter correct Employee Code \n");
		}
		//Validating address
		if(!(isValidPassword(bean.getPassword()))){
			validationErrors.add("\n Wrong password ! Password should contain minimum 5 characters \n");
		}
		
		if(!validationErrors.isEmpty())
		{
			throw new FeedBackException(validationErrors+"");
		}
	}

	private boolean isValidEmployeeCode(String employeeCode) {

		Pattern namePattern=Pattern.compile("^[A-Z]{1}[0-9]{4}");
		Matcher nameMatcher=namePattern.matcher(employeeCode);
		return nameMatcher.matches();
	}

	private boolean isValidPassword(String password) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{5,}");
		Matcher nameMatcher=namePattern.matcher(password);
		return nameMatcher.matches();
	}


}
