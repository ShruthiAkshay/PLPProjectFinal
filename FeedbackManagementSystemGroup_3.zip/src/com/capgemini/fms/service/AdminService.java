package com.capgemini.fms.service;

import java.util.ArrayList;
import java.util.List;






import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.fms.dao.AdminDAO;
import com.capgemini.fms.dao.IAdminDAO;
import com.capgemini.fms.dto.CourseBean;
import com.capgemini.fms.dto.FacultyBean;
import com.capgemini.fms.dto.FeedBackBean;
import com.capgemini.fms.exception.FeedBackException;

@Service
public class AdminService implements IAdminService{

	@Autowired
	IAdminDAO adminDao;
	//------------------------ Feedback Management System --------------------------//
		/*******************************************************************************
		 - Function Name	:	facultyMaintenance()
		 - Input Parameters	:   faculty
		 - Return Type		:	boolean
		 - Author			:	GROUP-3
		 - Description		:	facultyMaintenance method calls dao method which
		   						inserts into facultySkill table
		 ********************************************************************************/
	
	@Override
	public boolean facultyMaintenance(FacultyBean faculty) throws  FeedBackException {
		
		return adminDao.facultyMaintenance(faculty);
	}
	//------------------------ Feedback Management System --------------------------//
			/*******************************************************************************
			 - Function Name	:	courseMaintenance()
			 - Input Parameters	:   course
			 - Return Type		:	boolean
			 - Throws			:  	FeedBackException 
			 - Author			:	GROUP-3
			 - Description		:	courseMaintenance method calls dao method which
			 						inserts into courseMaster table
			 ********************************************************************************/

	@Override
	public boolean courseMaintenance(CourseBean course) throws  FeedBackException {
		
		return adminDao.courseMaintenance(course);
	}
	//------------------------ Feedback Management System --------------------------//
			/*******************************************************************************
			 - Function Name	:	viewFaculty()
			 - Return Type		:	list
			 - Throws			:  	FeedBackException 
			 - Author			:	GROUP-3
			 - Description		:	viewFaculty method calls dao method which
			 						prints the list from facultySkill table
			 ********************************************************************************/

	@Override
	public List<FacultyBean> viewFaculty() throws  FeedBackException{
		
		return adminDao.viewFaculty();
	}
	//------------------------ Feedback Management System --------------------------//
	/*******************************************************************************
	 - Function Name	:	updateFaculty()
	 - Input Parameters	:   faculty
	 - Return Type		:	boolean
	 - Throws			:  	FeedBackException 
	 - Author			:	GROUP-3
	 - Description		:   updateFaculty method calls dao method which
	 						updates the list in facultySkill table
	 ********************************************************************************/

	@Override
	public boolean updateFaculty(FacultyBean faculty) throws  FeedBackException {
		
		return adminDao.updateFaculty(faculty);
	}
	//------------------------ Feedback Management System --------------------------//
			/*******************************************************************************
			 - Function Name	:	deleteFaculty()
			 - Input Parameters	:   faculty,facultyCode
			 - Return Type		:	boolean
			 - Throws			:  	FeedBackException 
			 - Author			:	GROUP-3
			 - Description		:	deleteFaculty method calls dao method which
	 						        delete the list from facultySkill table
			 ********************************************************************************/

	@Override
	public boolean deleteFaculty(String facultyCode) throws  FeedBackException {
		
		return adminDao.deleteFaculty(facultyCode);
	}
	//------------------------ Feedback Management System --------------------------//
	/*******************************************************************************
	 - Function Name	:	viewFacultyWiseReport()
	 - Input Parameters	:   month
	 - Return Type		:	list
	 - Throws			:  	FeedBackException 
	 - Author			:	GROUP-3
	 - Description		:	viewFacultyWiseReport method calls dao method which
	 						returns the list of the faculty wise report by month 
	 						from feedbackMaster table
	 ********************************************************************************/

	@Override
	public List<FeedBackBean> viewFacultyWiseReport(int month) throws  FeedBackException {
		
		return adminDao.viewFacultyWiseReport(month);
	}
	
	@Override
	public FacultyBean retrieveFaculty(String facultyCode) {
		return adminDao.retrieveFaculty(facultyCode);
	}
	
	@Override
	public String retrieveFacultyCode(String trainingCode) {
		return adminDao.retrieveFacultyCode(trainingCode);
	}
	
	public void validateFaculty(FacultyBean facultybean) throws FeedBackException{
		
		List<String> validationErrors = new ArrayList<String>();
		
		//Validating faculty name
				if(!(isValidName(facultybean.getFacultyName()))) {
					validationErrors.add("\n Faculty Name Should Be In Alphabets and minimum 3 characters long ! \n");
				}
				
		//Validating Faculty Skill Set
				if(!(isValidSkillSet(facultybean.getSkillSet()))){
					validationErrors.add("\n Faculty should have minimum 1 skill set and should be a String \n");
				}		
				
		//Validating Faculty Code
				if(!(isValidFacultyCode(facultybean.getFacultyCode()))){
					validationErrors.add("\n Faculty Code should start with F followed by four digits respectively \n" );
				}
				if(!validationErrors.isEmpty())
				{
					throw new FeedBackException(validationErrors+"");
				}
	}
	
public void validateCourse(CourseBean course) throws FeedBackException{
		
		List<String> validationErrors = new ArrayList<String>();
		
		//Validating faculty name
				if(!(isValidCourseName(course.getCourseName()))) {
					validationErrors.add("\n Course Name Should Be In Alphabets and minimum 3 characters long ! \n");
				}
				
		//Validating Faculty Skill Set
				if(!(isValidNoOfDays(course.getNoOfDays()))){
					validationErrors.add("\n Number of days should be integer \n");
				}		
				
		//Validating Faculty Code
				if(!(isValidCourseCode(course.getCourseCode()))){
					validationErrors.add("\n Course Code should start with C followed by four digits respectively \n" );
				}
				if(!validationErrors.isEmpty())
				{
					throw new FeedBackException(validationErrors+"");
				}
	}
	

	public void validateFeedback(FeedBackBean feedbackBean) throws FeedBackException{
		
		List<String> validationErrors = new ArrayList<String>();
		
		//Validating Training Code
				if(!(isValidTrainingCode(feedbackBean.getTrainingCode()))) {
					validationErrors.add("\n Training Code should start with T followed by four digits respectively\n");
				}
				
		//Validating Participant Code
				if(!(isValidParticipantCode(feedbackBean.getParticipantCode()))){
					validationErrors.add("\n Participant Code start with P followed by four digits respectively \n");
				}		
				
		//Validating Communication feedback
				if(!(isValidCommunication(feedbackBean.getFbPrsComm()))){
					validationErrors.add("\n Communication feedback should be between 1 to 5 \n" );
				}
				
		//Validating Clarifying Doubts feedback
				if(!(isValidClarify(feedbackBean.getFbClrfyDbts()))){
					validationErrors.add("\n Clarification feedback should be between 1 to 5 \n" );
				}

		//Validating Time Management feedback
				if(!(isValidTime(feedbackBean.getFbTm()))){
					validationErrors.add("\n Time Management feedback should be between 1 to 5 \n" );
				}
				
		//Validating Course Handout feedback
				if(!(isValidHandOut(feedbackBean.getFbHndOut()))){
					validationErrors.add("\n HandOut feedback should be between 1 to 5 \n" );
				}
				
		//Validating Network feedback
				if(!(isValidNetwork(feedbackBean.getFbHwSwNtwrk()))){
					validationErrors.add("\n Network feedback should be between 1 to 5 \n" );
				}
				
		//Validating Comments
				if(!(isValidComments(feedbackBean.getComments()))){
					validationErrors.add("\n Comments feedback should be more than 5 characters \n" );
				}
				

	}
	
	
	private boolean isValidSuggestions(String suggestions) {
	
		return (suggestions.length() >= 5);
	}
	private boolean isValidComments(String comments) {

		return (comments.length() >= 5);
	}
	private boolean isValidNetwork(int fbHwSwNtwrk) {
		
		return (fbHwSwNtwrk)>0 && (fbHwSwNtwrk)<6;
	}
	private boolean isValidHandOut(int fbHndOut) {
		
		return (fbHndOut)>0 && (fbHndOut)<6;
	}
	private boolean isValidTime(int fbTm) {
		
		return (fbTm)>0 && (fbTm)<6;
	}
	private boolean isValidClarify(int fbClrfyDbts) {

		return (fbClrfyDbts)>0 && (fbClrfyDbts)<6;
	}
	private boolean isValidCommunication(int fbPrsComm) {

		return (fbPrsComm)>0 && (fbPrsComm)<6;
	}
	private boolean isValidParticipantCode(String participantCode) {

		Pattern namePattern=Pattern.compile("^[P]{1}[0-9]{4}");
		Matcher nameMatcher=namePattern.matcher(participantCode);
		return nameMatcher.matches();
	}
	private boolean isValidTrainingCode(String trainingCode) {
		Pattern namePattern=Pattern.compile("^[T]{1}[0-9]{4}");
		Matcher nameMatcher=namePattern.matcher(trainingCode);
		return nameMatcher.matches();
	}
	private boolean isValidFacultyCode(String facultyCode) {
		Pattern namePattern=Pattern.compile("^[F]{1}[0-9]{4}");
		Matcher nameMatcher=namePattern.matcher(facultyCode);
		return nameMatcher.matches();
	}
	private boolean isValidSkillSet(String skillSet) {
		
		Pattern namePattern=Pattern.compile("^[A-z+.]+(,[A-z+.]+)*$");
		Matcher nameMatcher=namePattern.matcher(skillSet);
		return nameMatcher.matches();
		
	}
	private boolean isValidName(String facultyName) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(facultyName);
		return nameMatcher.matches();
	}
	
	private boolean isValidCourseCode(String courseCode) {
		Pattern namePattern=Pattern.compile("^[C]{1}[0-9]{4}");
		Matcher nameMatcher=namePattern.matcher(courseCode);
		return nameMatcher.matches();
	}
	private boolean isValidNoOfDays(int noOfDays) {
	
		return (noOfDays>0);
	}
	private boolean isValidCourseName(String courseName) {
	
		Pattern namePattern=Pattern.compile("^[A-Za-z0-9+.]{3,}$");
		Matcher nameMatcher=namePattern.matcher(courseName);
		return nameMatcher.matches();
	}
	@Override
	public CourseBean retrieveCourse(String courseCode) {
		return adminDao.retrieveCourse(courseCode);
	}

	

}
