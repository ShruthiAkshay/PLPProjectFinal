package com.capgemini.fms.service;

import java.util.List;






import com.capgemini.fms.dto.CourseBean;
import com.capgemini.fms.dto.FacultyBean;
import com.capgemini.fms.dto.FeedBackBean;
import com.capgemini.fms.exception.FeedBackException;

public interface IAdminService {

	public boolean facultyMaintenance(FacultyBean faculty) throws FeedBackException ;
	public boolean courseMaintenance(CourseBean course) throws  FeedBackException;
	public List<FacultyBean> viewFaculty() throws  FeedBackException;
	public boolean updateFaculty(FacultyBean faculty) throws  FeedBackException;
	public boolean deleteFaculty(String facultyCode) throws  FeedBackException;
	public List<FeedBackBean> viewFacultyWiseReport(int month) throws FeedBackException;
	public FacultyBean retrieveFaculty(String facultyCode);
	public String retrieveFacultyCode(String trainingCode);
	public CourseBean retrieveCourse(String courseCode);
}
