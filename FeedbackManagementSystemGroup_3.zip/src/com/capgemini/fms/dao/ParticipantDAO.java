package com.capgemini.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.fms.dto.FeedBackBean;
import com.capgemini.fms.dto.ParticipantBean;
import com.capgemini.fms.exception.FeedBackException;

@Repository
@Transactional
public class ParticipantDAO implements IParticipantDAO{

	@PersistenceContext
	EntityManager entitymanager;
	PreparedStatement preparedStatement=null;		
	ResultSet resultSet = null;
	Connection conn = null;
	@Override
	public boolean participantFeedback(FeedBackBean feedBack) throws FeedBackException {
		try
		{
			entitymanager.persist(feedBack);
			return (true);
		}
		catch(Exception exp)
		{
			return false;
		}
	}
	@Override
	public String retrieveTrCode(String employeeCode) {
		 ParticipantBean  bean = entitymanager.find(ParticipantBean.class,employeeCode);
		 String trcode = bean.getTrainingCode();
		 return trcode;
	}
}	