package com.capgemini.fms.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.fms.dto.EmployeeBean;
import com.capgemini.fms.dto.ParticipantBean;

@Repository
@Transactional
public class EmployeeDAO implements IEmployeeDAO{
	
	
	@PersistenceContext
	EntityManager entitymanager;
	String role=null;
	
		
		@Override
		public EmployeeBean employeeLogin(String employeeCode, String password) {
			 boolean flag = false;
			String role=null;
			EmployeeBean bean1=entitymanager.find(EmployeeBean.class, employeeCode);
			   String pwd = bean1.getPassword();
				if((pwd).equals(password))
				{
				return bean1;
		}
				else
					return null;
}


		@Override
		public String retreiveTrainingCode(String employeeCode) {
			
			TypedQuery<ParticipantBean> query = entitymanager.createQuery(" from ParticipantBean WHERE participantCode=?", ParticipantBean.class);
			query.setParameter(1, employeeCode);
			ParticipantBean bean1 = query.getSingleResult(); 
			System.out.println(bean1);
			String trainingCode = bean1.getTrainingCode();
			return trainingCode;
		}
}