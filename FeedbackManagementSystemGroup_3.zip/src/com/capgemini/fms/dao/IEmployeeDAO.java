package com.capgemini.fms.dao;

import com.capgemini.fms.dto.EmployeeBean;

public interface IEmployeeDAO {

	public EmployeeBean employeeLogin(String employeeCode, String password);

	public String retreiveTrainingCode(String employeeCode);
}
