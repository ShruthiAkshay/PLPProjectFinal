package com.capgemini.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.fms.dto.CourseBean;
import com.capgemini.fms.dto.FacultyBean;
import com.capgemini.fms.dto.FeedBackBean;
import com.capgemini.fms.dto.TrainingProgramBean;
import com.capgemini.fms.exception.FeedBackException;

@Repository
@Transactional
public class AdminDAO implements IAdminDAO {

	@PersistenceContext
	EntityManager entitymanager;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	Connection conn = null;
	int queryResult = 0;

	@Override
	public boolean facultyMaintenance(FacultyBean faculty)
			throws FeedBackException {

		try {

			entitymanager.persist(faculty);

			return (true);
		} catch (Exception exp) {
			return false;
		}

	}

	@Override
	public boolean courseMaintenance(CourseBean course)
			throws FeedBackException {
		try {
			entitymanager.persist(course);
			return (true);
		} catch (Exception exp) {
			return false;
		}

	}

	@Override
	public List<FacultyBean> viewFaculty() throws FeedBackException {
		TypedQuery<FacultyBean> query = entitymanager.createQuery(
				"select faculty from FacultyBean faculty", FacultyBean.class);
		List<FacultyBean> list = query.getResultList();

		return list;
	}

	@Override
	public boolean updateFaculty(FacultyBean faculty) throws FeedBackException {
		boolean flag;
		if (faculty != null) {
			entitymanager.merge(faculty);
			flag = true;
		} else {
			System.out.println("NOT UPDATED");
			flag = false;
		}
		return flag;
	}

	@Override
	public boolean deleteFaculty(String facultyCode) throws FeedBackException {
		boolean flag;
		FacultyBean faculty1 = entitymanager.find(FacultyBean.class,
				facultyCode);
		if (faculty1 != null) {
			entitymanager.remove(faculty1);
			flag = true;
		} else
			flag = false;

		return flag;
	}

	@Override
	public List<FeedBackBean> viewFacultyWiseReport(int month)
			throws FeedBackException {
		TypedQuery<String> query = entitymanager
				.createQuery(
						"SELECT trainingCode FROM TrainingProgramBean WHERE MONTH(startDate)=:startMonth",
						String.class);
		System.out.println("Month : " + month);
		query.setParameter("startMonth", month);
		/* query.setParameter("endMonth", month); */

		List<String> list = query.getResultList();
		List<FeedBackBean> resultList = new ArrayList<FeedBackBean>();
	List<FeedBackBean> resultList1 = new ArrayList<FeedBackBean>();

		if (list.isEmpty()) {
			System.out.println("List Empty");
		} else {
			for (String tpb : list) {
				System.out.println(tpb);
				
				 TypedQuery<FeedBackBean> query2 = entitymanager.createQuery(
				 "SELECT feedback from FeedBackBean feedback WHERE trainingCode=:code"
				 , FeedBackBean.class); query2.setParameter("code",tpb);
				 resultList1 = query2.getResultList(); for(FeedBackBean fb :
				 resultList1){ resultList.add(fb); }
				 
			}
		}
		return resultList;
		/*
		 * String VIEW_FACULTY_REPORT =
		 * "SELECT f.fbPrsComm,f.fbClrfyDbts,f.fbTm  FROM	feedbackMaster f  INNER JOIN trainingProgram t ON t.trainingCode = f.trainingCode WHERE EXTRACT(MONTH FROM startDate)<= :startmonth AND EXTRACT(MONTH FROM endDate)>= :endmonth"
		 * ; Query query1 =
		 * entitymanager.createNativeQuery(VIEW_FACULTY_REPORT);
		 * query1.setParameter("startmonth", month);
		 * query1.setParameter("endmonth", month); List list =
		 * query1.getResultList();
		 */

		/*
		 * return list;
		 */}

	@Override
	public FacultyBean retrieveFaculty(String facultyCode) {
		FacultyBean facultybean = entitymanager.find(FacultyBean.class,
				facultyCode);
		return facultybean;
	}

	@Override
	public String retrieveFacultyCode(String trainingCode) {
		TypedQuery<TrainingProgramBean> query = entitymanager.createQuery(
				"FROM TrainingProgramBean WHERE trainingCode=:trCode",
				TrainingProgramBean.class);
		query.setParameter("trCode", trainingCode);
		TrainingProgramBean trbean = query.getSingleResult();
		String facultyCode = trbean.getFacultyCode();
		return facultyCode;
	}

	@Override
	public CourseBean retrieveCourse(String courseCode) {
		CourseBean courseBean = entitymanager.find(CourseBean.class, courseCode);
		return courseBean;
	}

}
