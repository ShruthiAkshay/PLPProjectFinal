package com.capgemini.fms.dto;
/**
 *Class Name :TrainingProgramBean
 *Package :com.capgemini.fms.dto 
 */
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="trainingProgram")
public class TrainingProgramBean {

	@Id
	@Column(name="trainingCode")
	private String trainingCode;
	@Column(name="courseCode")
	private String courseCode;
	@Column(name="facultyCode")
	private String facultyCode;
	 @DateTimeFormat(pattern = "yyyy-MM-dd") // This is for bind Date with @ModelAttribute
	    @Temporal(TemporalType.DATE)
	@Column(name="startDate")
	private Date startDate;
	 @DateTimeFormat(pattern = "yyyy-MM-dd") // This is for bind Date with @ModelAttribute
	    @Temporal(TemporalType.DATE)
	@Column(name="endDate")
	private Date endDate;
	 
	 
	 
	 
	/*
	 * Getters and Setter Methods
	 */
	public String getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(String trainingCode) {
		this.trainingCode = trainingCode;
	}
	public String getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	public String getFacultyCode() {
		return facultyCode;
	}
	public void setFacultyCode(String facultyCode) {
		this.facultyCode = facultyCode;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public TrainingProgramBean(String trainingCode, String courseCode,
			String facultyCode, Date startDate, Date endDate) {
		super();
		this.trainingCode = trainingCode;
		this.courseCode = courseCode;
		this.facultyCode = facultyCode;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	public TrainingProgramBean() {
		super();
	}
	
	
}
