package com.capgemini.fms.dto;

import javax.persistence.*;

/**
 *Class Name :EmployeeBean
 *Package :com.capgemini.fms.dto 
 */

@Entity
@Table(name="employeeMaster")
public class EmployeeBean {

	@Id
	@Column(name="EMPLOYEECODE")
	private String employeeCode;
	@Column(name="EMPLOYEENAME")
	private String employeeName;
	@Column(name="PASSWORD")
	private String password;
	@Column(name="ROLE")
	private String role;
	
	/*
	 * Getters and Setter Methods
	 */
	
	public String getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public EmployeeBean() {
	}
	
	public EmployeeBean(String employeeCode, String employeeName,
			String password, String role) {
		super();
		this.employeeCode = employeeCode;
		this.employeeName = employeeName;
		this.password = password;
		this.role = role;
	}
	@Override
	public String toString() {
		return "EmployeeBean [employeeCode=" + employeeCode + ", employeeName="
				+ employeeName + ", password=" + password + ", role=" + role
				+ "]";
	}

	
}
