package com.capgemini.fms.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

public class FetchBean {

	@Id
	@Column(name="trainingCode")
	private String trainingCode;
	@Column(name="participantCode")
	private String participantCode;
	@Column(name="fbPrsComm")
	private int fbPrsComm;
	@Column(name="fbClrfyDbts")
	private int fbClrfyDbts;
	@Column(name="fbTm")
	private int fbTm;
	@Column(name="fbHndOut")
	private int fbHndOut;
	@Column(name="fbHwSwNtwrk")
	private int fbHwSwNtwrk;
	@Column(name="comments")
	private String comments;
	@Column(name="courseCode")
	private String courseCode;
	@Column(name="facultyCode")
	private String facultyCode;
	 @DateTimeFormat(pattern = "yyyy-MM-dd") // This is for bind Date with @ModelAttribute
	    @Temporal(TemporalType.DATE)
	@Column(name="startDate")
	private Date startDate;
	 @DateTimeFormat(pattern = "yyyy-MM-dd") // This is for bind Date with @ModelAttribute
	    @Temporal(TemporalType.DATE)
	@Column(name="endDate")
	private Date endDate;
}
