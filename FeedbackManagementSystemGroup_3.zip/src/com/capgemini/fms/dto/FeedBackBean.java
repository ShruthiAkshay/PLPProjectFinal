package com.capgemini.fms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *Class Name :FeedBackBean
 *Package :com.capgemini.fms.dto 
 */

@Entity
@Table(name="feedbackMaster")
public class FeedBackBean {

	@Id
	@Column(name="trainingCode")
	private String trainingCode;
	@Column(name="participantCode")
	private String participantCode;
	@Column(name="fbPrsComm")
	private int fbPrsComm;
	@Column(name="fbClrfyDbts")
	private int fbClrfyDbts;
	@Column(name="fbTm")
	private int fbTm;
	@Column(name="fbHndOut")
	private int fbHndOut;
	@Column(name="fbHwSwNtwrk")
	private int fbHwSwNtwrk;
	@Column(name="comments")
	private String comments;
	/*
	 * Getters and Setter Methods
	 */
	public String getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(String trainingCode) {
		this.trainingCode = trainingCode;
	}
	public String getParticipantCode() {
		return participantCode;
	}
	public void setParticipantCode(String participantCode) {
		this.participantCode = participantCode;
	}
	public int getFbPrsComm() {
		return fbPrsComm;
	}
	public void setFbPrsComm(int fbPrsComm) {
		this.fbPrsComm = fbPrsComm;
	}
	public int getFbClrfyDbts() {
		return fbClrfyDbts;
	}
	public void setFbClrfyDbts(int fbClrfyDbts) {
		this.fbClrfyDbts = fbClrfyDbts;
	}
	public int getFbTm() {
		return fbTm;
	}
	public void setFbTm(int fbTm) {
		this.fbTm = fbTm;
	}
	public int getFbHndOut() {
		return fbHndOut;
	}
	public void setFbHndOut(int fbHndOut) {
		this.fbHndOut = fbHndOut;
	}
	public int getFbHwSwNtwrk() {
		return fbHwSwNtwrk;
	}
	public void setFbHwSwNtwrk(int fbHwSwNtwrk) {
		this.fbHwSwNtwrk = fbHwSwNtwrk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public FeedBackBean(String trainingCode, String participantCode,
			int fbPrsComm, int fbClrfyDbts, int fbTm, int fbHndOut,
			int fbHwSwNtwrk, String comments, String suggestions) {
		super();
		this.trainingCode = trainingCode;
		this.participantCode = participantCode;
		this.fbPrsComm = fbPrsComm;
		this.fbClrfyDbts = fbClrfyDbts;
		this.fbTm = fbTm;
		this.fbHndOut = fbHndOut;
		this.fbHwSwNtwrk = fbHwSwNtwrk;
		this.comments = comments;
	}
	public FeedBackBean() {
		super();
	}
	@Override
	public String toString() {
		return "FeedBackBean [trainingCode=" + trainingCode
				+ ", participantCode=" + participantCode + ", fbPrsComm="
				+ fbPrsComm + ", fbClrfyDbts=" + fbClrfyDbts + ", fbTm=" + fbTm
				+ ", fbHndOut=" + fbHndOut + ", fbHwSwNtwrk=" + fbHwSwNtwrk
				+ ", comments=" + comments + "]";
	}
	
}
