package com.capgemini.fms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *Class Name :ParticipantBean
 *Package :com.capgemini.fms.dto 
 */
@Entity
@Table(name="trainingParticipantEnrollment")
public class ParticipantBean {

	@Id
	@Column(name="trainingCode")
	private String trainingCode;
	@Column(name="participantCode")
	private String participantCode;
	/*
	 * Getters and Setter Methods
	 */
	public String getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(String trainingCode) {
		this.trainingCode = trainingCode;
	}
	public String getParticipantCode() {
		return participantCode;
	}
	public void setParticipantCode(String participantCode) {
		this.participantCode = participantCode;
	}
	public ParticipantBean(String trainingCode, String participantCode) {
		super();
		this.trainingCode = trainingCode;
		this.participantCode = participantCode;
	}
	public ParticipantBean() {
		super();
	}
	
}
