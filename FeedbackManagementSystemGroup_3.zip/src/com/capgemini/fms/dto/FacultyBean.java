package com.capgemini.fms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *Class Name :FacultyBean
 *Package :com.capgemini.fms.dto 
 */
@Entity
@Table(name="facultySkill")
public class FacultyBean {

	@Id
	@Column(name="facultyCode")
	private String facultyCode;
	@Column(name="skillSet")
	private String skillSet;
	@Column(name="facultyName")
	private String facultyName;
	/*
	 * Getters and Setter Methods
	 */
	public String getFacultyCode() {
		return facultyCode;
	}
	public void setFacultyCode(String facultyCode) {
		this.facultyCode = facultyCode;
	}
	public String getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	@Override
	public String toString() {
		return "FacultyBean [facultyCode=" + facultyCode + ", skillSet="
				+ skillSet + ", facultyName=" + facultyName + "]";
	}
	
	
	
}
