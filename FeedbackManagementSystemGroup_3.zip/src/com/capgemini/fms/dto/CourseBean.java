package com.capgemini.fms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *Class Name :CourseBean
 *Package :com.capgemini.fms.dto 
 */
@Entity
@Table(name="courseMaster")
public class CourseBean {

	@Id
	@Column(name="COURSECODE")
	private String courseCode;
	@Column(name="COURSENAME")
	private String courseName;
	@Column(name="NOOFDAYS")
	private int noOfDays;
	/*
	 * Getters and Setter Methods
	 */
	
	public String getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public CourseBean(String courseCode, String courseName, int noOfDays) {
		super();
		this.courseCode = courseCode;
		this.courseName = courseName;
		this.noOfDays = noOfDays;
	}
	public CourseBean() {
		super();
	}
	
	
}
