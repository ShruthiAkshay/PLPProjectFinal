package com.capgemini.fms.exception;

public class FeedBackException extends Exception 
{
	//------------------------ Feedback Management System --------------------------//
		/*******************************************************************************
		 - Author           :   GROUP-5
		 - Function Name	:	FeedBackException()
		 - Description 	    :   Handles the Exception
		  ********************************************************************************/

	private static final long serialVersionUID = 1L;

	public FeedBackException(String message) 
	{
		
		super(message);
	}
}
