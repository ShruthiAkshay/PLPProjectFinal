package com.capgemini.fms.controller;

import org.apache.log4j.Logger;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;


@Aspect
public class LoggerAspect {

	Logger logger = Logger.getRootLogger();
	
	@Before("execution(public * com.capgemini.fms.controller.MainController.*(..))")
	public void myAdvice(){
		logger.info("Before advice");
	}
}
