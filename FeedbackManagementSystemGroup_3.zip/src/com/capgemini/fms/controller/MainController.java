package com.capgemini.fms.controller;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.fms.dto.CourseBean;
import com.capgemini.fms.dto.EmployeeBean;
import com.capgemini.fms.dto.FacultyBean;
import com.capgemini.fms.dto.FeedBackBean;
import com.capgemini.fms.exception.FeedBackException;
import com.capgemini.fms.service.IAdminService;
import com.capgemini.fms.service.IEmployeeService;
import com.capgemini.fms.service.IParticipantService;

@Controller
public class MainController {

	@Autowired
	IEmployeeService empservice;
	@Autowired
	IAdminService adminservice;
	@Autowired
	IParticipantService participantService;

	public IEmployeeService getEmpservice() {
		return empservice;
	}

	public void setEmpservice(IEmployeeService empservice) {
		this.empservice = empservice;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	// @RequestMapping("/login")
	public ModelAndView login(
			@RequestParam("employeeCode") String employeeCode,
			@RequestParam("password") String password) {

		EmployeeBean bean = empservice.employeeLogin(employeeCode, password);
		ModelAndView model = new ModelAndView();

		if (bean == null) {

			model.setViewName("error");
			model.addObject("employeeCode", employeeCode);
			return (model);
		} else {
			String role = bean.getRole();
			if (role.equalsIgnoreCase("admin")) {
				model.setViewName("admin");
				model.addObject("employee", bean);
				model.addObject("adminname", bean.getEmployeeName());
			}
			/*
			 * else if(role.equalsIgnoreCase("coordinator")) {
			 * model.setViewName("coordinator");
			 * model.addObject("employee",bean); } else
			 * if(role.equalsIgnoreCase("participant")) {
			 * System.out.println(role); String trainingCode =
			 * empservice.retreiveTrainingCode(bean.getEmployeeCode());
			 * model.setViewName("participant");
			 * model.addObject("employee",bean); model.addObject("trainingCode",
			 * trainingCode); }
			 */

			return (model);
		}

	}

	/** Admin **/

	@RequestMapping("/add")
	public ModelAndView faculty(
			@RequestParam("facultyCode") String facultyCode,
			@ModelAttribute("Faculty") FacultyBean faculty, BindingResult result)
			throws FeedBackException {
		ModelAndView model = new ModelAndView();
		FacultyBean bean = new FacultyBean();
		bean = adminservice.retrieveFaculty(facultyCode);
		if (bean != null) {
			model.setViewName("error4");
			model.addObject("facultyCode", facultyCode);
			return (model);
		} else {
			if (result.hasErrors()) {
				model.setViewName("error");
				return (model);
			} else {
				boolean flag;
				flag = adminservice.facultyMaintenance(faculty);
				if (flag == false) {
					model.setViewName("error4");
					model.addObject("facultyCode", facultyCode);
					return (model);
				} else {
					model.setViewName("success");
					model.addObject("message",
							"Faculty Details added successfully");
					return (model);
				}
			}
		}
	}

	@RequestMapping("/viewAll")
	public ModelAndView viewAll() throws FeedBackException {
		System.out.println("in controller");
		ModelAndView model = new ModelAndView();
		List<FacultyBean> list = adminservice.viewFaculty();
		if (list.isEmpty()) {
			model.setViewName("error");
			model.addObject("message", "No Faculty Details Available");
			return (model);
		} else {
			model.setViewName("viewfaculty");
			model.addObject("facultylist", list);
			System.out.println(list);
			return (model);
		}
	}

	@RequestMapping("/course")
	public ModelAndView course(@RequestParam("courseCode") String courseCode,
			@ModelAttribute("Course") CourseBean course, BindingResult result)
			throws FeedBackException {
		ModelAndView model = new ModelAndView();
		CourseBean bean = new CourseBean();
		bean = adminservice.retrieveCourse(courseCode);
		if (bean != null) {
			String message = "error";
			model.setViewName("error3");
			model.addObject("courseCode", courseCode);
			model.addObject("message", message);
			return (model);
		} else {
			if (result.hasErrors()) {
				model.setViewName("error");
				return (model);
			} else {
				boolean flag;
				flag = adminservice.courseMaintenance(course);
				if (flag == false) {
					String message = "error";
					model.setViewName("error3");
					model.addObject("message", message);
					return (model);
				} else {
					model.setViewName("success");
					model.addObject("message",
							"Course Details added successfully");
					return (model);
				}
			}
		}
	}

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public ModelAndView update(@ModelAttribute("Faculty") FacultyBean faculty,
			BindingResult result) throws FeedBackException {
		if (result.hasErrors()) {
			ModelAndView model = new ModelAndView();
			model.setViewName("error");
			return model;
		}

		else {
			boolean flag = adminservice.updateFaculty(faculty);
			if (flag == false) {
				ModelAndView model = new ModelAndView();
				model.setViewName("error");
				model.addObject("message", "NOT UPDATED");
				return (model);
			} else {
				ModelAndView model = new ModelAndView("success");
				model.addObject("message",
						"Faculty Details Updated Succesfully");
				return (model);
			}

		}
	}

	@RequestMapping("/delete")
	public ModelAndView deleteFaculty(
			@RequestParam("facultyCode") String facultyCode)
			throws FeedBackException {
		ModelAndView model = new ModelAndView();
		System.out.println(facultyCode);
		boolean flag = adminservice.deleteFaculty(facultyCode);
		if (flag == true) {
			model.setViewName("success");
			model.addObject("message", "Faculty Details deleted successfully");
			return (model);
		} else {
			model.setViewName("error");
			model.addObject("message", "NOT DELETED");
			return (model);
		}
	}

	@RequestMapping("/viewdelete")
	public ModelAndView view(@RequestParam("facultyCode") String facultyCode) {
		FacultyBean facultybean = adminservice.retrieveFaculty(facultyCode);
		ModelAndView model = new ModelAndView();
		if (facultybean == null) {
			String message = "Error";
			model.addObject("message", message);
			model.addObject("facultyCode", facultyCode);
			model.setViewName("error1");
		} else {
			model = new ModelAndView("deletefaculty");
			model.addObject("var", true);
			model.addObject("faculty", facultybean);

		}
		return (model);
	}

	@RequestMapping("/viewupdate")
	public ModelAndView viewupdate(
			@RequestParam("facultyCode") String facultyCode) {
		FacultyBean facultybean = adminservice.retrieveFaculty(facultyCode);
		ModelAndView model = new ModelAndView();
		if (facultybean == null) {
			String message = "Error";
			model.addObject("message", message);
			model.addObject("facultyCode", facultyCode);
			model.setViewName("error1");
		} else {
			model = new ModelAndView("updatefaculty");
			model.addObject("var", true);
			model.addObject("faculty", facultybean);

		}
		return (model);
	}

	@RequestMapping("/viewFacultyFeedback")
	public ModelAndView viewFacultyFeedback(@RequestParam("month") int month)
			throws FeedBackException {
		ModelAndView model = new ModelAndView();
		List<FeedBackBean> list = adminservice.viewFacultyWiseReport(month);
		if (list.isEmpty()) {
			model.setViewName("error2");
			model.addObject("month", month);
			model.addObject("message", "No Feedback Available");
			return (model);
		} else {
			String facultyCode;
			DecimalFormat df = new DecimalFormat("####0.00");
			String avgAs;
			List<Double> listAvg = new ArrayList<Double>();
			List<String> facultyList = new ArrayList<String>();
			for (FeedBackBean fb : list) {
				facultyCode = adminservice.retrieveFacultyCode(fb
						.getTrainingCode());
				double avg = 0.0;
				avg = ((double) fb.getFbClrfyDbts()
						+ (double) fb.getFbPrsComm() + (double) fb.getFbTm()) / 3;
				avgAs = df.format(avg);
				facultyList.add(facultyCode);
				listAvg.add(Double.parseDouble(avgAs));
			}
			model.setViewName("viewFacultyFeedback");
			model.addObject("feedbackList", listAvg);
			model.addObject("facultyCode", facultyList);
			return (model);
		}

	}

}
