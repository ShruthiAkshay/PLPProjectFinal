CREATE TABLE employeeMaster(EMPLOYEECODE number(5) PRIMARY KEY, EMPLOYEENAME varchar2(30), PASSWORD varchar2(30),
ROLE varchar2(30));

Insert into employeeMaster values(1,'valli','valli','Admin');
Insert into employeeMaster values(2,'harshitha','harshitha','Admin');

CREATE TABLE facultySkill(facultyCode number(5),skillset varchar2(30),FOREIGN KEY(facultyCode) REFERENCES employeeMaster(EMPLOYEECODE));

CREATE TABLE courseMaster(COURSECODE number(5), COURSENAME varchar2(30), NOOFDAYS number(5), PRIMARY KEY(COURSECODE));

CREATE TABLE trainingProgram(trainingCode number(5) PRIMARY KEY,courseCode number(5),facultyCode number(5),startDate date,endDate date,
FOREIGN KEY(courseCode) REFERENCES courseMaster(COURSECODE),FOREIGN KEY(facultyCode) REFERENCES facultySkill(facultyCode));

CREATE TABLE feedbackMaster(trainingCode number(5),participantCode number(5),fbPrsComm number(1),fbClrfyDbts number(1),
fbTm number(1),fbHndOut number(1),fbHwSwNtwrk number(1),comments varchar2(100),FOREIGN KEY(trainingCode) REFERENCES trainingProgram(trainingCode),
FOREIGN KEY(participantCode) REFERENCES employeeMaster(EMPLOYEECODE));

CREATE TABLE trainingParticipantEnrollment(trainingCode number(5),participantCode number(5),
FOREIGN KEY(trainingCode) REFERENCES trainingProgram(trainingCode),
FOREIGN KEY(participantCode) REFERENCES Employee_master(EMPLOYEECODE));

INSERT INTO trainingProgram values('T1001','C1001','08-01-2018','F1001','09-01-2018');
INSERT INTO trainingProgram values('T1002','C1002','01-01-2018','F1002','02-01-2018');


INSERT INTO feedbackMaster VALUES('T1001','P1001',5,4,3,5,5,'Good');
INSERT INTO feedbackMaster VALUES('T1002','P1002',5,5,5,5,5,'Good');